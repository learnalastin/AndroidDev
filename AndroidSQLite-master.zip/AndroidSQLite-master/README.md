Android **Notes App** demonstrating **SQLite** database.

[Tutorial](https://www.androidhive.info/2011/11/android-sqlite-database-tutorial/)

[Apk](http://download.androidhive.info/apk/sqlite-notes-app.apk)

[Video Demo](https://www.youtube.com/watch?v=4YxUtIkG_gc)

![Android SQLite Notes App](https://www.androidhive.info/wp-content/uploads/2011/11/android-sqlite-notes-app.png)