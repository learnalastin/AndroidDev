package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class Activity2 extends AppCompatActivity {

    private TextView mTextViewResult;
    private EditText editText;
    private Button button4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);

        editText = findViewById(R.id.editText);
        button4 = findViewById(R.id.button4);

        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            button4.setEnabled(false);

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            String editText = editText.getText().toString();
            button4.setEnabled(true);
            }

            @Override
            public void afterTextChanged(Editable s) {
            button4.setEnabled(true);
            }
        });

        mTextViewResult = findViewById(R.id.textView);
        Button buttonOpen = findViewById(R.id.button_open);

        buttonOpen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Activity2.this, Activity3.class);
                startActivityForResult(intent, 1);

            }
        });

        Intent intent = getIntent();
        String text = intent.getStringExtra(MainActivity.EXTRA_TEXT);
        String text1 = intent.getStringExtra(MainActivity.EXTRA_TEXT1);
        int number = intent.getIntExtra(MainActivity.EXTRA_NUMBER, 0);

        TextView textView1 = (TextView) findViewById(R.id.textview1);
        TextView textView2 = (TextView) findViewById(R.id.textview2);
        TextView textView3 = (TextView) findViewById(R.id.textview3);

        textView1.setText(text);
        textView3.setText(text1);
        textView2.setText("" + number);



    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1) {
            if (resultCode == RESULT_OK) {
                String start = data.getStringExtra("start");
                String end = data.getStringExtra("end");

                mTextViewResult.setText("Taxi will arrive at" + start + "in 5 minutes and take you to" + end +
                        "If you agree press call taxi");
                editText.setText("Driver reserved");
            }
        }
    }









}