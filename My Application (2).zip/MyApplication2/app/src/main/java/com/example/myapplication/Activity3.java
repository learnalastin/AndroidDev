package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class Activity3 extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_3);

        setTitle("Activity 3");


/////start

        EditText editText = (EditText) findViewById(R.id.edittext);
        String text = editText.getText().toString();

        EditText editText1 = (EditText) findViewById(R.id.edittext1);
        String text1 = editText1.getText().toString();

        EditText editText2 = (EditText) findViewById(R.id.edittext2);
        String text2 = editText2.getText().toString();


////dest

        EditText editText3 = (EditText) findViewById(R.id.edittext3);
        String text3 = editText3.getText().toString();

        EditText editText4 = (EditText) findViewById(R.id.edittext4);
        String text4 = editText4.getText().toString();

        EditText editText5 = (EditText) findViewById(R.id.edittext5);
        String text5 = editText5.getText().toString();


////pack
        final String startRes = "Street: " + text + "House: " + text1 + "Flat: " + text2;
        final String endRes = "Street: " + text3 + "House: " + text4 + "Flat: " + text5;

        Button button = findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String start = startRes;
                String end = endRes;

                Intent intent = new Intent();
                intent.putExtra("start", start);
                intent.putExtra("end", end);

                setResult(RESULT_OK, intent);
                finish();

            }
        });







    }
}